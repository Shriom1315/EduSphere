import { useState } from 'react';
import { supabase } from '../lib/supabase';
import toast from 'react-hot-toast';

export const useFileUpload = () => {
  const [uploading, setUploading] = useState(false);
  const [progress, setProgress] = useState(0);

  const uploadFile = async (
    file: File,
    bucket: string,
    path?: string
  ): Promise<{ success: boolean; url?: string; error?: string }> => {
    try {
      setUploading(true);
      setProgress(0);

      const fileExt = file.name.split('.').pop();
      const fileName = `${Date.now()}-${Math.random().toString(36).substring(2)}.${fileExt}`;
      const filePath = path ? `${path}/${fileName}` : fileName;

      // Simulate upload progress
      const progressInterval = setInterval(() => {
        setProgress((prev) => Math.min(prev + 10, 90));
      }, 100);

      const { data, error } = await supabase.storage
        .from(bucket)
        .upload(filePath, file);

      clearInterval(progressInterval);
      setProgress(100);

      if (error) throw error;

      // Get public URL
      const { data: { publicUrl } } = supabase.storage
        .from(bucket)
        .getPublicUrl(filePath);

      toast.success('File uploaded successfully!');
      return { success: true, url: publicUrl };
    } catch (error: any) {
      toast.error(error.message || 'Failed to upload file');
      return { success: false, error: error.message };
    } finally {
      setUploading(false);
      setProgress(0);
    }
  };

  const deleteFile = async (
    bucket: string,
    path: string
  ): Promise<{ success: boolean; error?: string }> => {
    try {
      const { error } = await supabase.storage
        .from(bucket)
        .remove([path]);

      if (error) throw error;

      toast.success('File deleted successfully!');
      return { success: true };
    } catch (error: any) {
      toast.error(error.message || 'Failed to delete file');
      return { success: false, error: error.message };
    }
  };

  return {
    uploadFile,
    deleteFile,
    uploading,
    progress,
  };
};