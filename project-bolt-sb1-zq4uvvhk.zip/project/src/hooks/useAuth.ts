import { useState, useEffect } from 'react';
import { User } from '@supabase/supabase-js';
import { supabase } from '../lib/supabase';
import { User as AppUser } from '../types';
import toast from 'react-hot-toast';

export const useAuth = () => {
  const [user, setUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Get initial session
    supabase.auth.getSession().then(({ data: { session } }) => {
      if (session?.user) {
        fetchUserProfile(session.user.id);
      } else {
        setLoading(false);
      }
    });

    // Listen for auth changes
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (event, session) => {
        if (session?.user) {
          await fetchUserProfile(session.user.id);
        } else {
          setUser(null);
          setLoading(false);
        }
      }
    );

    return () => subscription.unsubscribe();
  }, []);

  const fetchUserProfile = async (userId: string) => {
    try {
      const { data, error } = await supabase
        .from('users')
        .select('*')
        .eq('id', userId)
        .single();

      if (error) throw error;

      if (data) {
        const appUser: AppUser = {
          id: data.id,
          name: data.name,
          email: data.email,
          role: data.role,
          schoolId: data.school_id,
          phone: data.phone,
          qualification: data.qualification,
          classId: data.class_id,
          rollNumber: data.roll_number,
          parentName: data.parent_name,
          parentPhone: data.parent_phone,
          isFirstLogin: data.is_first_login,
          createdAt: data.created_at,
          lastLogin: data.last_login,
        };
        setUser(appUser);
      }
    } catch (error) {
      console.error('Error fetching user profile:', error);
      toast.error('Failed to load user profile');
    } finally {
      setLoading(false);
    }
  };

  const signIn = async (email: string, password: string) => {
    try {
      setLoading(true);
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) throw error;

      // Update last login
      if (data.user) {
        await supabase
          .from('users')
          .update({ last_login: new Date().toISOString() })
          .eq('id', data.user.id);
      }

      toast.success('Signed in successfully!');
      return { success: true };
    } catch (error: any) {
      toast.error(error.message || 'Failed to sign in');
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  };

  const signUp = async (email: string, password: string, userData: Partial<AppUser>) => {
    try {
      setLoading(true);
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
      });

      if (error) throw error;

      if (data.user) {
        // Create user profile
        const { error: profileError } = await supabase
          .from('users')
          .insert({
            id: data.user.id,
            email: data.user.email!,
            name: userData.name!,
            role: userData.role!,
            school_id: userData.schoolId,
            phone: userData.phone,
            qualification: userData.qualification,
            class_id: userData.classId,
            roll_number: userData.rollNumber,
            parent_name: userData.parentName,
            parent_phone: userData.parentPhone,
            is_first_login: true,
          });

        if (profileError) throw profileError;
      }

      toast.success('Account created successfully!');
      return { success: true };
    } catch (error: any) {
      toast.error(error.message || 'Failed to create account');
      return { success: false, error: error.message };
    } finally {
      setLoading(false);
    }
  };

  const signOut = async () => {
    try {
      const { error } = await supabase.auth.signOut();
      if (error) throw error;
      
      setUser(null);
      toast.success('Signed out successfully!');
    } catch (error: any) {
      toast.error(error.message || 'Failed to sign out');
    }
  };

  const updateProfile = async (updates: Partial<AppUser>) => {
    try {
      if (!user) throw new Error('No user logged in');

      const { error } = await supabase
        .from('users')
        .update({
          name: updates.name,
          phone: updates.phone,
          qualification: updates.qualification,
          parent_name: updates.parentName,
          parent_phone: updates.parentPhone,
        })
        .eq('id', user.id);

      if (error) throw error;

      setUser({ ...user, ...updates });
      toast.success('Profile updated successfully!');
      return { success: true };
    } catch (error: any) {
      toast.error(error.message || 'Failed to update profile');
      return { success: false, error: error.message };
    }
  };

  const changePassword = async (newPassword: string) => {
    try {
      const { error } = await supabase.auth.updateUser({
        password: newPassword,
      });

      if (error) throw error;

      // Mark as not first login
      if (user) {
        await supabase
          .from('users')
          .update({ is_first_login: false })
          .eq('id', user.id);

        setUser({ ...user, isFirstLogin: false });
      }

      toast.success('Password changed successfully!');
      return { success: true };
    } catch (error: any) {
      toast.error(error.message || 'Failed to change password');
      return { success: false, error: error.message };
    }
  };

  return {
    user,
    loading,
    signIn,
    signUp,
    signOut,
    updateProfile,
    changePassword,
  };
};